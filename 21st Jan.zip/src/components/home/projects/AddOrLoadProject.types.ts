export interface AddNewProjectForm {
  name: string;
}
