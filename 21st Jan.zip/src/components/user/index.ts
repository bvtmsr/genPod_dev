import Projects from './projects/Projects';

const User = {
  Projects
};

export default User;
