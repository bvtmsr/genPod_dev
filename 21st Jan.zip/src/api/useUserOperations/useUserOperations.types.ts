export enum Status {
	ACTIVE = 'ACTIVE',
	INACTIVE = 'INACTIVE',
}
export interface UserDTO {
  username: string;
  id: string;
}
