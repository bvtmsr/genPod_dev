export const getInitialDBNodeFormData = () => {
	return {
		port: '',
	}
}
