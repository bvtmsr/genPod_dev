const icons = [
    { value: "angular", label: "Angular", path: "/nodeIcons/angular.png" },
    { value: "Amazon-Augmented-AI-A2I", label: "Amazon Augmented AI A2I", path: "/nodeIcons/Amazon-Augmented-AI-A2I.png" },
    { value: "typescript", label: "TypeScript", path: "/nodeIcons/typescript.png" },
    { value: "sample", label: "Sample", path: "/nodeIcons/sample.png" },
    { value: "react", label: "React", path: "/nodeIcons/react.png" },
    { value: "php", label: "PHP", path: "/nodeIcons/php.png" },
    { value: "one", label: "One", path: "/nodeIcons/one.png" },
    { value: "nextjs", label: "Next.js", path: "/nodeIcons/nextjs.png" },
    { value: "mysql", label: "MySQL", path: "/nodeIcons/mysql.png" },
    { value: "magento", label: "Magento", path: "/nodeIcons/magento.png" },
    { value: "kubernetes", label: "Kubernetes", path: "/nodeIcons/kubernetes.png" },
    { value: "java", label: "Java", path: "/nodeIcons/java.png" },
    { value: "four", label: "Four", path: "/nodeIcons/four.png" },
    { value: "five", label: "Five", path: "/nodeIcons/five.png" },
    { value: "dot-net", label: ".NET", path: "/nodeIcons/dot-net.png" },
    { value: "two", label: "Two", path: "/nodeIcons/two.png" },
    { value: "three", label: "Three", path: "/nodeIcons/three.png" }
];

export default icons;