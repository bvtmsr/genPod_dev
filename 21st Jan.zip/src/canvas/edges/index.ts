import { EdgeTypes } from '../store/types.store';
import CustomEdge from './CustomEdge';

export const edgeTypes = {
  [EdgeTypes.CUSTOM_EDGE]: CustomEdge
};
