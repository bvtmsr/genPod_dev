/// <reference types="vite/client" />

declare module 'xterm-theme';
